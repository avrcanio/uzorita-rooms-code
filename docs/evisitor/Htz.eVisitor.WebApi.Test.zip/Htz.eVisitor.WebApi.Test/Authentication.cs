﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Htz.eVisitor.WebApi.Test
{
    [TestClass]
    public class Authentication
    {
        [TestMethod]
        public void CanAuthenticate()
        {
            var authCookie = Utility.Login();
            Assert.IsNotNull(authCookie);
            Utility.Logout(authCookie);
        }
         
    }
}
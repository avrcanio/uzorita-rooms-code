<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</HEAD>

<?php
$pathToFile = "/var/www/HTZ_REST_client/";
$authenticationServiceUrl = "https://www.evisitor.hr/eVisitorRhetos_API/Resources/AspNetFormsAuth/Authentication/";
$restServiceUrl = "https://www.evisitor.hr/eVisitorRhetos_API/Rest/Htz/";

/* Login section */
echo "<u>Login</u><br>"; 
$username = "username";
$password = "password";
$apikey = "apikey";
$data = array("UserName" => $username, "Password" => $password, "PersistCookie" => "false", "apikey" => $apikey);
$data_string = json_encode($data); 
                                                                                  
$resource = "Login";
$login_url = $authenticationServiceUrl.$resource;
$ch = curl_init($login_url);                                            
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
curl_setopt($ch, CURLOPT_VERBOSE, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);          
//curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'DEFAULT@SECLEVEL=1');      //odkomentirati ukoliko php vrati error: "SSL routines:tls_process_ske_dhe:dh key too small"
curl_setopt($ch, CURLOPT_HTTPHEADER, array(                                                                         
    'Content-Type: application/json',                                                                               
    'Content-Length: ' . strlen($data_string))                                                                      
);
                                                                                                                  
$response = curl_exec($ch);
$responseCode = curl_getinfo($ch)['http_code'];
$cookieContent = get_headers_from_curl_response($response)["Set-Cookie"];
echo "Cookie content: ".$cookieContent."<br>";


list($header, $body) = explode("\r\n\r\n", $response, 2);
if ($responseCode == "200" && $body == "true") 
	echo "OK";
else 
	echo "Error";

if ($responseCode == "200" && $body == "true") {
	
	# Check in section
	echo "<br><br><u>Check in</u><br>";
	$check_in_data = read_from_file($pathToFile."TouristCheckIn.xml");
	$check_in_request_data = array("Xml" => $check_in_data, "Register" => "true");
	$check_in_data_string = json_encode($check_in_request_data);

	$resource = "ImportTourists/";
	$check_in_url = $restServiceUrl.$resource;
	$ch = curl_init($check_in_url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                    
	curl_setopt($ch, CURLOPT_POSTFIELDS, $check_in_data_string);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_COOKIE, $cookieContent);
	//curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'DEFAULT@SECLEVEL=1');      //odkomentirati ukoliko php vrati error: "SSL routines:tls_process_ske_dhe:dh key too small"
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Content-Type: application/json; charset=utf-8',
		'Content-Length: ' . strlen($check_in_data_string))
	);
	
	$response = curl_exec($ch);
	$responseCode = curl_getinfo($ch)['http_code'];
	if ($responseCode == "200") {
		echo "OK";
	} else {
		echo "Error: ".$response;
	}

	# Check out section 
	echo "<br><br><u>Check out</u><br>";

	$check_out_data = read_from_file($pathToFile."TouristCheckOut.xml");
	$check_out_request_data = array("Xml" => $check_out_data);
	$check_out_data_string = json_encode($check_out_request_data);

	$resource = "ImportTouristCheckOut/";
	$check_out_url = $restServiceUrl.$resource;
	$ch = curl_init($check_out_url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $check_out_data_string);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_COOKIE, $cookieContent);
	//curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'DEFAULT@SECLEVEL=1');      //odkomentirati ukoliko php vrati error: "SSL routines:tls_process_ske_dhe:dh key too small"
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Content-Type: application/json',
		'Content-Length: ' . strlen($check_out_data_string))
	);                                                 
	$response = curl_exec($ch);
	$responseCode = curl_getinfo($ch)['http_code'];
	if ($responseCode == "200") {
		echo "OK";
	} else {
		echo "Error: ".$response;
	}


	# Edit check in section 
	echo "<br><br><u>Edit check in</u><br>";
	$edit_check_in_data = read_from_file($pathToFile."EditOfExistingCheckIn.xml");
	$edit_check_in_request_data = array("Xml" => $edit_check_in_data, "Register" => "true");
	$edit_check_in_data_string = json_encode($edit_check_in_request_data);

	$resource = "ImportTourists/";
	$edit_check_in_url = $restServiceUrl.$resource;
	$ch = curl_init($edit_check_in_url);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
	curl_setopt($ch, CURLOPT_POSTFIELDS, $edit_check_in_data_string);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_COOKIE, $cookieContent);
	//curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'DEFAULT@SECLEVEL=1');      //odkomentirati ukoliko php vrati error: "SSL routines:tls_process_ske_dhe:dh key too small"
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Content-Type: application/json',
		'Content-Length: ' . strlen($edit_check_in_data_string))
	);                                                 
	$response = curl_exec($ch);
	$responseCode = curl_getinfo($ch)['http_code'];
	if ($responseCode == "200") {
		echo "OK";
	} else {
		echo "Error: ".$response;
	}
	
	echo "<br><br><u>Logout section</u><br>";
	$resource = "Logout";
	$logoout_url = $authenticationServiceUrl.$resource;
	$ch = curl_init($logoout_url);
	curl_setopt($ch, CURLOPT_COOKIE, $cookieContent);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); 
	curl_setopt($ch, CURLOPT_VERBOSE, 1);
	curl_setopt($ch, CURLOPT_HEADER, 0);                                                                     
	//curl_setopt($ch, CURLOPT_SSL_CIPHER_LIST, 'DEFAULT@SECLEVEL=1');      //odkomentirati ukoliko php vrati error: "SSL routines:tls_process_ske_dhe:dh key too small"
	curl_setopt($ch, CURLOPT_HTTPHEADER, array(
		'Content-Type: application/json',
		'Content-Length: 0')                                                                       
	);
		
	$response = curl_exec($ch);
	$responseCode = curl_getinfo($ch)['http_code'];
	if ($responseCode == "200") {
		echo "OK";
	} else {
		echo "Error: ".$response;
	}

}

function get_headers_from_curl_response($response)
{
	$headers = array();
	$header_text = substr($response, 0, strpos($response, "\r\n\r\n"));
	foreach (explode("\r\n", $header_text) as $i => $line)
		if ($i === 0)
			$headers['http_code'] = $line;
		else
		{
			list ($key, $value) = explode(': ', $line);
			if ($key == "Set-Cookie") {
				$value = str_replace('HttpOnly', '', $value);
			}
			
			if (isset($headers[$key])){
				$headers[$key] = $headers[$key]."; ".$value;
			} else {
				$headers[$key] = $value;
			}
		}
	return $headers;
}

function read_from_file($targetFile) 
{
	//samo zadnji dio koristiti ako se poziva kroz cli
	//apsolutni put koristiti ako se testira pozivom kroz web server
	$urlTargetFile = $targetFile;

	$xmlfile = fopen($urlTargetFile, "r") or die("Unable to open file!");
	$data = fread($xmlfile,filesize($urlTargetFile));
	fclose($xmlfile);
	return $data;
}

?>

</HTML>
